﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleDIDemo
{
    public class ClassA : IInterfaceA
    {
        public void doA()
        {
            Console.WriteLine("Do A");
        }
    }
}
