﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleDIDemo
{
    public interface IInterfaceB
    {
        void DoB();
    }
}
