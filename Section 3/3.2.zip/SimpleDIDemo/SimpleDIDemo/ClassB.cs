﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleDIDemo
{
    public class ClassB : IInterfaceB
    {
        private IInterfaceA _classA;

        public ClassB(IInterfaceA classA)
        {
            _classA = classA;
        }

        public void DoB()
        {
            _classA.doA();
            Console.WriteLine("Do B");
        }
    }
}
