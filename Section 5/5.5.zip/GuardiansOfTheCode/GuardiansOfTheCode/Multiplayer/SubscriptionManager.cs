﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuardiansOfTheCode.Multiplayer
{
    public class SubscriptionManager
    {
        public IState CurrentState;
    }
}
