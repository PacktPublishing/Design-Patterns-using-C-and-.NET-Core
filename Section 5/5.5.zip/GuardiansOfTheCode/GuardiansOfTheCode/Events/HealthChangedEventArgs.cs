﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuardiansOfTheCode.Events
{
    public class HealthChangedEventArgs : EventArgs
    {
        public int Health { get; private set; }
        public int Damage { get; set; }

        public HealthChangedEventArgs(int health)
        {
            Health = health;
        }
    }
}
