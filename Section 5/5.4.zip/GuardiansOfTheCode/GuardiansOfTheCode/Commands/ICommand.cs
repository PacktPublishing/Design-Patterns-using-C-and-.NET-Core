﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GuardiansOfTheCode.Commands
{
    public interface ICommand
    {
        void Execute();
    }
}
